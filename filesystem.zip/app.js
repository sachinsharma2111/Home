const express = require('express');
const fs = require('fs');
const multer = require('multer');
const path = require('path');

const app = express();

// Set up Multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname);
  },
});

const upload = multer({ storage });

// Serve static files
app.use(express.static('public'));

// Render the file upload form
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Handle file upload
app.post('/upload', upload.single('file'), (req, res) => {
  const sourceFilePath = req.file.path;
  const targetFolderPath = 'designated-folder/';

  // Check file permissions
  fs.access(sourceFilePath, fs.constants.W_OK, (err) => {
    if (err) {
      res.send('You do not have write permissions for the file.');
    } else {
      // Check folder permissions
      fs.access(targetFolderPath, fs.constants.W_OK, (err) => {
        if (err) {
          res.send('The target folder does not have write permissions for you.');
        } else {
          // Perform the file move operation
          fs.rename(sourceFilePath, path.join(targetFolderPath, req.file.originalname), (err) => {
            if (err) {
              res.send('An error occurred while moving the file.');
            } else {
              res.send('File moved successfully.');
            }
          });
        }
      });
    }
  });
});

// Start the server
app.listen(3000, () => {
  console.log('Server listening on port 3000');
});
